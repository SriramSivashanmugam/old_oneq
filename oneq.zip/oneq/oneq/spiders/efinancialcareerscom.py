# homepage: https://www.efinancialcareers.com/

# template: conc_demand.py

# category page: https://www.efinancialcareers.com/search/?q=financial%20analyst&location=New%20Brunswick,%20NJ,%20USA&latitude=40.4862157&longitude=-74.4518188&countryCode=US&locationPrecision=City&radius=50&radiusUnit=mi&page=1&pageSize=20&currencyCode=USD&language=en

# product link: https://www.efinancialcareers.com/jobs-USA-NY-New_York-Financial_Analyst.id12480037?searchlink=search%2F%3Fq%3Dfinancial%2520analyst%26location%3DNew%2520Brunswick%2C%2520NJ%2C%2520USA%26latitude%3D40.4862157%26longitude%3D-74.4518188%26countryCode%3DUS%26locationPrecision%3DCity%26radius%3D50%26radiusUnit%3Dmi%26page%3D1%26pageSize%3D20%26currencyCode%3DUSD%26language%3Den&searchId=3df2fbf1-1a72-4110-b3b6-144dc1de0ba0

# Fields to be scraped: company name, salary, job description, location
